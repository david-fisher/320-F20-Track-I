package team8.partyinthebackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EthicsApplicationTests {

	@Test
	void contextLoads() {
	}

}
