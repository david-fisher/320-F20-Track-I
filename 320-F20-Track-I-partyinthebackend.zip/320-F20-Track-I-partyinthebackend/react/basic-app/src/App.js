import React from 'react';
import logo from './logo.svg';
import './App.css';
import HomepageComponent from './components/HomepageComponent';

function App() {
  return (
    <div className="App">
      <HomepageComponent/>
    </div>
  );
}

export default App;
