package team8.partyinthebackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EthicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(EthicsApplication.class, args);
	}

}
